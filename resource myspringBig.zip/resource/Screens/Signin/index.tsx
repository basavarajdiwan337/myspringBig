import React from 'react'
import { View, Text, SafeAreaView, Button, Dimensions, Image } from 'react-native';
import { useRoute } from '@react-navigation/native';
const device = Dimensions.get('window');
export const deviceWidth = device.width;
export const deviceHeight = device.height;
import AppStyle from '../../Configuration/index';
const Signin = ({ navigation }: any) => {
    const onPressButton = () => {
        navigation.navigate('PinEntry');
    }
    let newStyle = new AppStyle().getStyle();
    let config = new AppStyle().getConfig();
    console.log("config===>", config);

    const route = useRoute();
    console.log("route=======>", route.name);

    return (
        <SafeAreaView style={newStyle.signincontainer}>
            <View style={{ backgroundColor: 'red', flex: 1,width:deviceWidth,justifyContent:'center' }}>
            {config.Imagetext}
            </View>
            <View style={{ flex: 1,backgroundColor:'yellow',width:deviceWidth,justifyContent:'center' }}>
                <Text style={{ textAlign: 'center',color:'black' }}>
                    Hi, Well come Signin.
                </Text>
                <Button
                    title="Next Page"
                    color="#f194ff"
                    onPress={onPressButton}
                />
            </View>
            <View style={{ flex: 1,backgroundColor:'green',width:deviceWidth,justifyContent:'center' }}>
                <Text style={{ textAlign: 'center',color:'black' }}>
                    Hi, Well come Signin.
                </Text>
                <Button
                    title="Next Page"
                    color="#f194ff"
                    onPress={onPressButton}
                />


            </View>

        </SafeAreaView>
    );
};

export default Signin;