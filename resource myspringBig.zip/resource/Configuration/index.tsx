import React from 'react';
import { View,Image } from 'react-native';
import { useRoute } from '@react-navigation/native';
import Stylesheet from '../StyleSheet/thebakeree'
export default class styleSignIn {

    public getStyle = () => {
        const route = useRoute();
        let signinText : any;
        let style : any;
        console.log(route.name,"<======page name");
        switch (route.name) {
            case 'Signin' : style=Stylesheet;
            break;
        }
       
        return style
    }

    public getConfig = () => {
        const route = useRoute();
        
        let signinText : any;
        let Imagetext : any;
        let style : any;
        console.log(route.name,"<======page name");
        switch (route.name) {
            case 'Signin' : 
            signinText = {tittle : 'Signin page',
        color : 'red'}
        Imagetext = <Image source={require('../Assets/images/flowerPotImg.png')}/>
            break;
        }
       
        return {signinText,Imagetext}
    }
}



